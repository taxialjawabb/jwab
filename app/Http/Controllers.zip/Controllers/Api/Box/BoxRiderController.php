<?php

namespace App\Http\Controllers\Api\Box;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class BoxRiderController extends Controller
{
    //
}
