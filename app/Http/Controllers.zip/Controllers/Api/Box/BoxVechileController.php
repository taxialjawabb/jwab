<?php

namespace App\Http\Controllers\Api\Box;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class BoxVechileController extends Controller
{
    //
}
